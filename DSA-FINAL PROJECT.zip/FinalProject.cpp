﻿#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <iomanip>
#include <sstream>
using namespace std;
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define MAGENTA "\033[35m"
#define CYAN    "\033[36m"
#define BOLD    "\033[1m"
void clearInputBuffer()
{
    if (cin.peek() == '\n') cin.ignore();
}

string inputLine(const string& prompt = "")
{
    if (!prompt.empty()) cout << prompt;
    string s;
    getline(cin, s);
    return s;
}

int inputInt(const string& prompt = "")
{
    if (!prompt.empty()) cout << prompt;
    int v;
    while (!(cin >> v))
    {
        cin.clear();
        clearInputBuffer();
        cout << RED << "   [ERROR] Please enter a valid number: " << RESET;
    }
    clearInputBuffer();
    return v;
}

double inputDouble(const string& prompt = "")
{
    if (!prompt.empty()) cout << prompt;
    double v;
    while (!(cin >> v))
    {
        cin.clear();
        clearInputBuffer();
        cout << RED << "   [ERROR] Please enter a valid number: " << RESET;
    }
    clearInputBuffer();
    return v;
}

class Student;
class Course;

// SLL
struct StudentNode
{
    string studentID;
    string studentName;
    StudentNode* next;

    StudentNode(string id, string name)
    {
        studentID = id;
        studentName = name;
        next = NULL;
    }
};

class SinglyLinkedList
{
private:
    StudentNode* head;
public:
    SinglyLinkedList()
    {
        head = NULL;
    }

    void addStudent(string id, string name)
    {
        StudentNode* newNode = new StudentNode(id, name);
        newNode->next = head;
        head = newNode;
    }

    void removeStudent(string id)
    {
        if (!head) return;
        if (head->studentID == id)
        {
            StudentNode* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        StudentNode* current = head;
        while (current->next && current->next->studentID != id)
            current = current->next;
        if (current->next)
        {
            StudentNode* temp = current->next;
            current->next = temp->next;
            delete temp;
        }
    }

    void displayStudents()
    {
        StudentNode* current = head;
        if (!current)
        {
            cout << "     No students enrolled.\n";
            return;
        }
        cout << "     +--------------------+----------------------+\n";
        cout << "     | " << left << setw(18) << "Student ID" << " | " << setw(20) << "Name" << " |\n";
        cout << "     +--------------------+----------------------+\n";
        while (current)
        {
            cout << "     | " << left << setw(18) << current->studentID
                << " | " << setw(20) << current->studentName << " |\n";
            current = current->next;
        }
        cout << "     +--------------------+----------------------+\n";
    }

    bool isEnrolled(string id)
    {
        StudentNode* current = head;
        while (current)
        {
            if (current->studentID == id) return true;
            current = current->next;
        }
        return false;
    }

    StudentNode* getHead() { return head; }
};

// DLL
struct CourseNode
{
    string courseCode;
    string courseName;
    CourseNode* next;
    CourseNode* prev;

    CourseNode(string code, string name)
    {
        courseCode = code;
        courseName = name;
        next = NULL;
        prev = NULL;
    }
};

class DoublyLinkedList
{
private:
    CourseNode* head;
    CourseNode* tail;
public:
    DoublyLinkedList()
    {
        head = NULL;
        tail = NULL;
    }

    void addCourse(string code, string name)
    {
        CourseNode* newNode = new CourseNode(code, name);
        if (!head)
        {
            head = newNode;
            tail = newNode;
            return;
        }
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }

    void removeCourse(string code)
    {
        if (!head) return;
        CourseNode* current = head;
        while (current && current->courseCode != code)
            current = current->next;
        if (!current) return;
        if (current->prev) current->prev->next = current->next;
        else head = current->next;
        if (current->next) current->next->prev = current->prev;
        else tail = current->prev;
        delete current;
    }

    bool hasCourse(string code)
    {
        CourseNode* current = head;
        while (current)
        {
            if (current->courseCode == code) return true;
            current = current->next;
        }
        return false;
    }

    void displayCourses()
    {
        CourseNode* current = head;
        if (!current) { cout << "     No courses enrolled.\n"; return; }
        cout << "     +----------+------------------------------------------+\n";
        cout << "     | " << left << setw(8) << "Code" << " | " << setw(40) << "Course Name" << " |\n";
        cout << "     +----------+------------------------------------------+\n";
        while (current)
        {
            cout << "     | " << left << setw(8) << current->courseCode
                << " | " << setw(40) << current->courseName << " |\n";
            current = current->next;
        }
        cout << "     +----------+------------------------------------------+\n";
    }

    CourseNode* getHead() { return head; }

    int getCount()
    {
        int count = 0;
        CourseNode* current = head;
        while (current) { count++; current = current->next; }
        return count;
    }
};

// stack
struct Submission
{
    string courseCode;
    string assignmentName;
    string submissionDate;
    Submission* next;

    Submission(string code, string name, string date)
    {
        courseCode = code;
        assignmentName = name;
        submissionDate = date;
        next = NULL;
    }
};

class Stack
{
private:
    Submission* top;
public:
    Stack()
    {
        top = NULL;
    }

    void push(string courseCode, string assignmentName, string date)
    {
        Submission* newSub = new Submission(courseCode, assignmentName, date);
        newSub->next = top;
        top = newSub;
        cout << GREEN << "   [SUCCESS] Assignment submitted successfully!\n" << RESET;
    }

    void pop()
    {
        if (!top)
        {
            cout << RED << "   [ERROR] No submissions to undo!\n" << RESET;
            return;
        }
        Submission* temp = top;
        top = top->next;
        cout << YELLOW << "   [INFO] Last submission undone!\n" << RESET;
        delete temp;
    }

    void display()
    {
        if (!top) { cout << "     No submissions yet.\n"; return; }
        Submission* current = top;
        int count = 1;
        cout << CYAN << "     Submission History (Latest First):\n" << RESET;
        cout << "     +----+----------+----------------------+------------+\n";
        cout << "     | #  | Course   | Assignment           | Date       |\n";
        cout << "     +----+----------+----------------------+------------+\n";
        while (current)
        {
            cout << "     | " << left << setw(2) << count++
                << " | " << setw(8) << current->courseCode
                << " | " << setw(20) << current->assignmentName
                << " | " << setw(10) << current->submissionDate << " |\n";
            current = current->next;
        }
        cout << "     +----+----------+----------------------+------------+\n";
    }
};

// Queue
struct Notification
{
    string message;
    string date;
    Notification* next;

    Notification(string msg, string d)
    {
        message = msg;
        date = d;
        next = NULL;
    }
};

class Queue
{
private:
    Notification* front;
    Notification* rear;
public:
    Queue()
    {
        front = NULL;
        rear = NULL;
    }

    void enqueue(string message, string date)
    {
        Notification* newNotif = new Notification(message, date);
        if (!rear)
        {
            front = newNotif;
            rear = newNotif;
            return;
        }
        rear->next = newNotif;
        rear = newNotif;
    }

    void dequeue()
    {
        if (!front) 
            return;
        Notification* temp = front;
        front = front->next;
        if (!front) 
            rear = NULL;
        delete temp;
    }

    void displayAll()
    {
        if (!front) { 
            cout << "     No notifications.\n";
            return; 
        }
        Notification* current = front;
        cout << YELLOW << "\n     NOTIFICATIONS:\n" << RESET;
        cout << "     +---------------------------------+------------+\n";
        cout << "     | " << left << setw(31) << "Message" << " | " << setw(10) << "Date" << " |\n";
        cout << "     +---------------------------------+------------+\n";
        while (current)
        {
            cout << "     | " << left << setw(31) << current->message
                << " | " << setw(10) << current->date << " |\n";
            current = current->next;
        }
        cout << "     +---------------------------------+------------+\n\n";
    }

    bool isEmpty() { return front == NULL; }
};

// Hashtable
class HashTable
{
private:
    static const int TABLE_SIZE = 101;

    struct UserEntry
    {
        string username;
        string password;
        string role;
        bool isEmpty;

        UserEntry()
        {
            isEmpty = true;
        }
    };

    UserEntry table[TABLE_SIZE];

    int hashFunction(string key)
    {
        int hash = 0;
        for (int i = 0; i < (int)key.size(); i++)
            hash = (hash * 31 + key[i]) % TABLE_SIZE;
        return hash;
    }

public:
    void insert(string username, string password, string role)
    {
        int index = hashFunction(username);
        while (!table[index].isEmpty && table[index].username != username)
            index = (index + 1) % TABLE_SIZE;
        table[index].username = username;
        table[index].password = password;
        table[index].role = role;
        table[index].isEmpty = false;
    }

    bool authenticate(string username, string password, string& role)
    {
        int index = hashFunction(username);
        int startIndex = index;
        while (!table[index].isEmpty)
        {
            if (table[index].username == username)
            {
                if (table[index].password == password)
                {
                    role = table[index].role;
                    return true;
                }
                return false;
            }
            index = (index + 1) % TABLE_SIZE;
            if (index == startIndex) break;
        }
        return false;
    }
};

// Graph
class PrerequisiteGraph
{
private:
    vector<string> courses;
    vector<vector<int> > adjList;

    int getCourseIndex(string code)
    {
        for (int i = 0; i < (int)courses.size(); i++)
            if (courses[i] == code) return i;
        return -1;
    }

public:
    void addCourse(string code)
    {
        courses.push_back(code);
        adjList.resize(courses.size());
    }

    void addPrerequisite(string course, string prereq)
    {
        int cIndex = getCourseIndex(course);
        int pIndex = getCourseIndex(prereq);
        if (cIndex != -1 && pIndex != -1)
            adjList[cIndex].push_back(pIndex);
    }

    bool courseExists(string course)
    {
        return getCourseIndex(course) != -1;
    }

    bool checkPrerequisites(string course, vector<string>& completedCourses)
    {
        int cIndex = getCourseIndex(course);
        if (cIndex == -1) return false;

        vector<bool> completed(courses.size(), false);
        for (int i = 0; i < (int)completedCourses.size(); i++)
        {
            int idx = getCourseIndex(completedCourses[i]);
            if (idx != -1) completed[idx] = true;
        }

        bool allMet = true;
        for (int i = 0; i < (int)adjList[cIndex].size(); i++)
        {
            int prereq = adjList[cIndex][i];
            if (!completed[prereq])
            {
                cout << RED << "     [ERROR] Prerequisite not completed: " << courses[prereq] << RESET << "\n";
                allMet = false;
            }
        }
        return allMet;
    }

    void displayPrerequisites(string course)
    {
        int cIndex = getCourseIndex(course);
        if (cIndex == -1)
        {
            cout << "     Course not found in prerequisite system.\n";
            return;
        }
        if (adjList[cIndex].empty())
        {
            cout << "     No prerequisites for this course.\n";
            return;
        }
        cout << "     Prerequisites (" << course << "): ";
        for (int i = 0; i < (int)adjList[cIndex].size(); i++)
            cout << courses[adjList[cIndex][i]] << " ";
        cout << "\n";
    }
};

// BST
struct BSTNode
{
    string key;
    string value;
    BSTNode* left;
    BSTNode* right;

    BSTNode(string k, string v)
    {
        key = k;
        value = v;
        left = NULL;
        right = NULL;
    }
};

class BinarySearchTree
{
private:
    BSTNode* root;

    BSTNode* insert(BSTNode* node, string key, string value)
    {
        if (!node) return new BSTNode(key, value);
        if (key < node->key) node->left = insert(node->left, key, value);
        else if (key > node->key) node->right = insert(node->right, key, value);
        return node;
    }

    BSTNode* search(BSTNode* node, string key)
    {
        if (!node || node->key == key) return node;
        if (key < node->key) return search(node->left, key);
        return search(node->right, key);
    }

public:
    BinarySearchTree()
    {
        root = NULL;
    }

    void insert(string key, string value)
    {
        root = insert(root, key, value);
    }

    string search(string key)
    {
        BSTNode* result = search(root, key);
        return result ? result->value : "";
    }
};

// Max heap

class MaxHeap
{
private:
    struct StudentRecord
    {
        string name;
        string id;
        double gpa;
    };

    StudentRecord* heap;
    int heapSize;
    int capacity;

    void maxHeapify(int i)
    {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int largest = i;

        if (left < heapSize && heap[left].gpa > heap[largest].gpa)
            largest = left;

        if (right < heapSize && heap[right].gpa > heap[largest].gpa)
            largest = right;

        if (largest != i)
        {
            swap(heap[i], heap[largest]);
            maxHeapify(largest);
        }
    }

    void buildMaxHeap()
    {
        for (int i = heapSize / 2 - 1; i >= 0; i--)
            maxHeapify(i);
    }

public:
    MaxHeap(int cap)
    {
        capacity = cap;
        heapSize = 0;
        heap = new StudentRecord[capacity];
    }
    void loadStudents(string names[], string ids[], double gpas[], int count)
    {
        heapSize = count;
        for (int i = 0; i < count; i++)
        {
            heap[i].name = names[i];
            heap[i].id = ids[i];
            heap[i].gpa = gpas[i];
        }
        buildMaxHeap();
    }

    void displayTop(int count)
    {
        if (heapSize == 0)
        {
            cout << "     No students.\n";
            return;
        }

        int toShow = count;
        if (toShow > heapSize) toShow = heapSize;

        cout << CYAN << "\n     TOP " << toShow << " STUDENTS BY GPA:\n" << RESET;
        cout << "     +----+----------------------+--------------------+-------+\n";
        cout << "     | #  | Name                 | ID                 | GPA   |\n";
        cout << "     +----+----------------------+--------------------+-------+\n";

        bool visited[100] = { false };

        for (int rank = 1; rank <= toShow; rank++)
        {
            int bestIndex = -1;
            for (int i = 0; i < heapSize; i++)
            {
                if (!visited[i])
                {
                    if (bestIndex == -1 || heap[i].gpa > heap[bestIndex].gpa)
                        bestIndex = i;
                }
            }

            if (bestIndex != -1)
            {
                cout << "     | " << left << setw(2) << rank
                    << " | " << setw(20) << heap[bestIndex].name
                    << " | " << setw(18) << heap[bestIndex].id
                    << " | " << fixed << setprecision(2) << setw(5) << heap[bestIndex].gpa << " |\n";
                visited[bestIndex] = true;
            }
        }

        cout << "     +----+----------------------+--------------------+-------+\n";
    }
};
// Quick sort
class QuickSort
{
public:
    struct StudentScore
    {
        string name;
        string id;
        double gpa;
    };

    void sort(StudentScore arr[], int low, int high)
    {
        if (low < high)
        {
            int pi = partition(arr, low, high);
            sort(arr, low, pi - 1);
            sort(arr, pi + 1, high);
        }
    }

    int partition(StudentScore arr[], int low, int high)
    {
        double pivot = arr[high].gpa;
        int i = low - 1;

        for (int j = low; j < high; j++)
        {
            if (arr[j].gpa >= pivot)
            {
                i++;
                swap(arr[i], arr[j]);
            }
        }

        swap(arr[i + 1], arr[high]);

        return i + 1;
    }
};
// Merge sort
class MergeSort
{
public:
    void sort(string arr[], int left, int right)
    {
        if (left < right)
        {
            int mid = left + (right - left) / 2;
            sort(arr, left, mid);
            sort(arr, mid + 1, right);
            merge(arr, left, mid, right);
        }
    }

    void merge(string arr[], int left, int mid, int right)
    {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        string* L = new string[n1];
        string* R = new string[n2];

        for (int i = 0; i < n1; i++) L[i] = arr[left + i];
        for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

        int i = 0, j = 0, k = left;

        while (i < n1 && j < n2)
        {
            if (L[i] <= R[j])
            {
                arr[k] = L[i];
                i++;
            }
            else
            {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            arr[k] = R[j];
            j++;
            k++;
        }

        delete[] L;
        delete[] R;
    }
};

class Course
{
public:
    string code, name;
    int theoryCredits, labCredits;
    string teacher, day, time, room;
    SinglyLinkedList enrolledStudents;
    double attendancePercentage;
    int totalClasses;

    Course()
    {
        theoryCredits = 0;
        labCredits = 0;
        attendancePercentage = 0;
        totalClasses = 0;
    }

    Course(string c, string n, int th, int lab, string t, string d, string tm, string r)
    {
        code = c;
        name = n;
        theoryCredits = th;
        labCredits = lab;
        teacher = t;
        day = d;
        time = tm;
        room = r;
        attendancePercentage = 85.0;
        totalClasses = 20;
    }

    void displayInfo()
    {
        int totalCredits = theoryCredits + labCredits;
        cout << "     +---------------------------------------------------+\n";
        cout << "     | Code    : " << left << setw(40) << code << "|\n";
        cout << "     | Name    : " << left << setw(40) << name << "|\n";
        cout << "     | Credits : " << left << setw(40) << (to_string(totalCredits) + (labCredits > 0 ? " [Lab: " + to_string(labCredits) + "]" : "")) << "|\n";
        cout << "     | Teacher : " << left << setw(40) << teacher << "|\n";
        cout << "     | Schedule: " << left << setw(40) << (day + ", " + time) << "|\n";
        cout << "     | Room    : " << left << setw(40) << room << "|\n";
        cout << "     +---------------------------------------------------+\n";
    }
};

// 2D array
class Timetable
{
private:
    string days[5];
    string slots[6];

    struct Slot
    {
        string courseCode;
        string teacher;
        string room;
        bool occupied;

        Slot()
        {
            occupied = false;
        }
    };

    Slot schedule[5][6];

public:
    Timetable()
    {
        days[0] = "Monday";
        days[1] = "Tuesday";
        days[2] = "Wednesday";
        days[3] = "Thursday";
        days[4] = "Friday";

        slots[0] = "8:30-10:00";
        slots[1] = "10:15-11:45";
        slots[2] = "12:00-1:30";
        slots[3] = "2:00-3:30";
        slots[4] = "3:45-5:15";
        slots[5] = "5:30-7:00";
    }

    void addCourse(int dayIndex, int slotIndex, string courseCode, string teacher, string room)
    {
        if (dayIndex >= 0 && dayIndex < 5 && slotIndex >= 0 && slotIndex < 6)
        {
            schedule[dayIndex][slotIndex].courseCode = courseCode;
            schedule[dayIndex][slotIndex].teacher = teacher;
            schedule[dayIndex][slotIndex].room = room;
            schedule[dayIndex][slotIndex].occupied = true;
        }
    }

    void display()
    {
        cout << BLUE;
        cout << "\n     +-------------+------------+------------+------------+------------+------------+\n";
        cout << "     |   Time      |   MONDAY   |  TUESDAY   | WEDNESDAY  | THURSDAY   |   FRIDAY   |\n";
        cout << "     +-------------+------------+------------+------------+------------+------------+\n";

        for (int s = 0; s < 6; s++)
        {
            cout << "     | " << left << setw(11) << slots[s] << " |";
            for (int d = 0; d < 5; d++)
            {
                if (schedule[d][s].occupied)
                {
                    string code = schedule[d][s].courseCode;
                    if ((int)code.length() > 10) code = code.substr(0, 10);
                    cout << " " << left << setw(10) << code << " |";
                }
                else
                {
                    cout << "            |";
                }
            }
            cout << "\n";

            cout << "     |             |";
            for (int d = 0; d < 5; d++)
            {
                if (schedule[d][s].occupied)
                {
                    string room = schedule[d][s].room;
                    if ((int)room.length() > 10) room = room.substr(0, 10);
                    cout << " " << left << setw(10) << room << " |";
                }
                else
                {
                    cout << "            |";
                }
            }
            cout << "\n";
            cout << "     +-------------+------------+------------+------------+------------+------------+\n";
        }
        cout << RESET;
    }
};

class Student
{
public:
    string id, name, password;
    int semester;
    double gpa;
    DoublyLinkedList enrolledCourses;
    Stack submissionStack;
    Queue notificationQueue;
    string completedCourses[50];
    int completedCount;

    Student()
    {
        semester = 1;
        gpa = 0.0;
        completedCount = 0;
    }

    Student(string i, string n, int s, double g)
    {
        id = i;
        name = n;
        semester = s;
        gpa = g;
        completedCount = 0;
    }

    void addCompletedCourse(string courseCode)
    {
        for (int i = 0; i < completedCount; i++)
            if (completedCourses[i] == courseCode) return;
        completedCourses[completedCount] = courseCode;
        completedCount++;
    }

    vector<string> getCompletedCourses()
    {
        vector<string> result;
        for (int i = 0; i < completedCount; i++)
            result.push_back(completedCourses[i]);
        return result;
    }

    void checkAttendanceAlert(Course courses[], int courseCount)
    {
        bool hasShortage = false;
        CourseNode* current = enrolledCourses.getHead();
        while (current)
        {
            for (int i = 0; i < courseCount; i++)
            {
                if (courses[i].code == current->courseCode)
                {
                    double attendance = courses[i].attendancePercentage;
                    if (attendance < 75 && attendance > 0)
                    {
                        cout << RED << "     [ALERT] " << current->courseCode
                            << " - " << fixed << setprecision(1) << attendance << "% (Below 75%)\n" << RESET;
                        hasShortage = true;
                    }
                    break;
                }
            }
            current = current->next;
        }
        if (!hasShortage)
            cout << GREEN << "     All courses have satisfactory attendance (75% or above)\n" << RESET;
    }

    void showMenu(Course allCourses[][20], int semesterCourseCount[], PrerequisiteGraph& prereqGraph,
        Timetable timetable[], int studentIndex, Student students[], int studentCount);
};

class Admin
{
public:
    void manageStudentCourses(Student students[], int studentCount,
        Course courses[][20], int semesterCourseCount[]);
    void manageTimetable(Timetable timetable[], Course courses[][20], int semesterCourseCount[]);
    void checkPrerequisiteAlert(Student& student, string courseCode, PrerequisiteGraph& prereqGraph);
    void viewCourseEnrollmentDetails(Course courses[][20], int semesterCourseCount[],
        Student students[], int studentCount);
    void showMenu(Student students[], int& studentCount, Course allCourses[][20],
        int semesterCourseCount[], PrerequisiteGraph& prereqGraph,
        Timetable timetable[], HashTable& loginSystem);
};

const int MAX_SEMESTERS = 8;
const int MAX_COURSES_PER_SEM = 20;
Course allCourses[MAX_SEMESTERS][MAX_COURSES_PER_SEM];
int courseCountPerSem[MAX_SEMESTERS] = { 0 };
Student students[100];
int studentCount = 0;
PrerequisiteGraph prereqGraph;
Timetable timetable[MAX_SEMESTERS];

void enrollStudentInSemesterCourses(Student& student, Course allCourses[][20], int semesterCourseCount[])
{
    int semIndex = student.semester - 1;
    if (semIndex >= 0 && semIndex < MAX_SEMESTERS)
    {
        int coursesToEnroll = semesterCourseCount[semIndex];
        if (coursesToEnroll > 4) coursesToEnroll = 4;

        for (int i = 0; i < coursesToEnroll; i++)
        {
            string courseCode = allCourses[semIndex][i].code;
            string courseName = allCourses[semIndex][i].name;
            if (!student.enrolledCourses.hasCourse(courseCode))
            {
                student.enrolledCourses.addCourse(courseCode, courseName);
                allCourses[semIndex][i].enrolledStudents.addStudent(student.id, student.name);
            }
        }
    }
}
void initializeData()
{
    // sem 1
    courseCountPerSem[0] = 9;
    allCourses[0][0] = Course("GSC 114", "Applied Physics", 2, 0, "Dr. Ahmed", "Monday", "8:30-10:00", "Room 101");
    allCourses[0][1] = Course("GSL 113", "Applied Physics Lab", 0, 1, "Dr. Ahmed", "Monday", "10:15-11:45", "Room Lab1");
    allCourses[0][2] = Course("CSC 114", "Introduction to ICT", 2, 0, "Dr. Fatima", "Tuesday", "8:30-10:00", "Room 102");
    allCourses[0][3] = Course("CSL 114", "ICT Lab", 0, 1, "Dr. Fatima", "Tuesday", "10:15-11:45", "Room Lab2");
    allCourses[0][4] = Course("CSC 113", "Computer Programming", 3, 0, "Dr. Ali", "Wednesday", "8:30-10:00", "Room 103");
    allCourses[0][5] = Course("CSL 113", "Computer Programming Lab", 0, 1, "Dr. Ali", "Wednesday", "10:15-11:45", "Room Lab3");
    allCourses[0][6] = Course("GSC 221", "Discrete Mathematics", 3, 0, "Dr. Khan", "Thursday", "8:30-10:00", "Room 104");
    allCourses[0][7] = Course("ISL 101", "Islamic Studies/Ethics", 2, 0, "Mr. Usman", "Thursday", "10:15-11:45", "Room 105");
    allCourses[0][8] = Course("CSC 308", "Professional Practices & Ethics", 2, 0, "Ms. Sara", "Friday", "8:30-10:00", "Room 106");

    // Sem 2
    courseCountPerSem[1] = 9;
    allCourses[1][0] = Course("GSC 122", "Probability and Statistics", 3, 0, "Dr. Khan", "Monday", "8:30-10:00", "Room 201");
    allCourses[1][1] = Course("CSC 210", "Object Oriented Programming", 3, 0, "Dr. Ali", "Monday", "10:15-11:45", "Room 202");
    allCourses[1][2] = Course("CSL 210", "OOP Lab", 0, 1, "Dr. Ali", "Tuesday", "8:30-10:00", "Room Lab4");
    allCourses[1][3] = Course("CEN 122", "Digital Design", 2, 0, "Dr. Fatima", "Tuesday", "10:15-11:45", "Room 203");
    allCourses[1][4] = Course("CEL 122", "Digital Design Lab", 0, 1, "Dr. Fatima", "Wednesday", "8:30-10:00", "Room Lab5");
    allCourses[1][5] = Course("GSC 110", "Applied Calculus", 3, 0, "Dr. Khan", "Wednesday", "10:15-11:45", "Room 204");
    allCourses[1][6] = Course("ENG 101", "Functional English", 3, 0, "Ms. Sara", "Thursday", "8:30-10:00", "Room 205");
    allCourses[1][7] = Course("PAK 103", "Pakistan Studies", 2, 0, "Mr. Usman", "Thursday", "10:15-11:45", "Room 206");
    allCourses[1][8] = Course("ISL 108", "Understanding Quran-I", 1, 0, "Mr. Usman", "Friday", "8:30-10:00", "Room 207");

    // sem 3
    courseCountPerSem[2] = 9;
    allCourses[2][0] = Course("HSS 219", "Civic and Community Engagement", 2, 0, "Ms. Sara", "Monday", "8:30-10:00", "Room 301");
    allCourses[2][1] = Course("GSC 121", "Linear Algebra", 3, 0, "Dr. Khan", "Monday", "10:15-11:45", "Room 302");
    allCourses[2][2] = Course("GSC 211", "Multivariable Calculus", 3, 0, "Dr. Khan", "Tuesday", "8:30-10:00", "Room 303");
    allCourses[2][3] = Course("CEN 223", "Computer Communication & Networks", 3, 0, "Dr. Ahmed", "Tuesday", "10:15-11:45", "Room 304");
    allCourses[2][4] = Course("CEL 223", "CCN Lab", 0, 1, "Dr. Ahmed", "Wednesday", "8:30-10:00", "Room Lab6");
    allCourses[2][5] = Course("CSC 221", "Data Structure & Algorithm", 3, 0, "Dr. Ali", "Wednesday", "10:15-11:45", "Room 305");
    allCourses[2][6] = Course("CSL 221", "DSA Lab", 0, 1, "Dr. Ali", "Thursday", "8:30-10:00", "Room Lab7");
    allCourses[2][7] = Course("ENG 134", "Communication Skills", 2, 0, "Ms. Sara", "Thursday", "10:15-11:45", "Room 306");
    allCourses[2][8] = Course("ISL 109", "Understanding Quran-II", 1, 0, "Mr. Usman", "Friday", "8:30-10:00", "Room 307");

    // sem 4
    courseCountPerSem[3] = 8;
    allCourses[3][0] = Course("SSE", "Social Sciences Elective", 3, 0, "Dr. Fatima", "Monday", "8:30-10:00", "Room 401");
    allCourses[3][1] = Course("CEN 323", "Computer Organization & Assembly", 2, 0, "Dr. Ahmed", "Monday", "10:15-11:45", "Room 402");
    allCourses[3][2] = Course("CEL 323", "COAL Lab", 0, 1, "Dr. Ahmed", "Tuesday", "8:30-10:00", "Room Lab8");
    allCourses[3][3] = Course("ENG 123", "Expository Writing", 3, 0, "Ms. Sara", "Tuesday", "10:15-11:45", "Room 403");
    allCourses[3][4] = Course("CSC 220", "Database Management Systems", 3, 0, "Dr. Ali", "Wednesday", "8:30-10:00", "Room 404");
    allCourses[3][5] = Course("CSL 220", "DBMS Lab", 0, 1, "Dr. Ali", "Wednesday", "10:15-11:45", "Room Lab9");
    allCourses[3][6] = Course("HSS 423", "Entrepreneurship", 2, 0, "Mr. Usman", "Thursday", "8:30-10:00", "Room 405");
    allCourses[3][7] = Course("SEN 220", "Software Engineering", 3, 0, "Dr. Fatima", "Thursday", "10:15-11:45", "Room 406");

    // sem 5
    courseCountPerSem[4] = 9;
    allCourses[4][0] = Course("CSC 320", "Operating Systems", 3, 0, "Dr. Ahmed", "Monday", "8:30-10:00", "Room 501");
    allCourses[4][1] = Course("CSL 320", "OS Lab", 0, 1, "Dr. Ahmed", "Monday", "10:15-11:45", "Room Lab10");
    allCourses[4][2] = Course("CSC 315", "Theory of Automata", 3, 0, "Dr. Fatima", "Tuesday", "8:30-10:00", "Room 502");
    allCourses[4][3] = Course("CSC 321", "Design and Analysis of Algorithms", 3, 0, "Dr. Ali", "Tuesday", "10:15-11:45", "Room 503");
    allCourses[4][4] = Course("CSC 327", "Computer Architecture", 2, 0, "Dr. Khan", "Wednesday", "8:30-10:00", "Room 504");
    allCourses[4][5] = Course("CSL 327", "Computer Architecture Lab", 0, 1, "Dr. Khan", "Wednesday", "10:15-11:45", "Room Lab11");
    allCourses[4][6] = Course("CSC 412", "Artificial Intelligence", 3, 0, "Dr. Ali", "Thursday", "8:30-10:00", "Room 505");
    allCourses[4][7] = Course("CSL 411", "AI Lab", 0, 1, "Dr. Ali", "Thursday", "10:15-11:45", "Room Lab12");
    allCourses[4][8] = Course("ISL 111", "Understanding Quran-IV", 1, 0, "Mr. Usman", "Friday", "8:30-10:00", "Room 506");

    // sem 6
    courseCountPerSem[5] = 10;
    allCourses[5][0] = Course("CSC 323", "Compiler Construction", 2, 0, "Dr. Fatima", "Monday", "8:30-10:00", "Room 601");
    allCourses[5][1] = Course("CSL 323", "Compiler Construction Lab", 0, 1, "Dr. Fatima", "Monday", "10:15-11:45", "Room Lab13");
    allCourses[5][2] = Course("E1", "Elective 1", 2, 0, "Dr. Ahmed", "Tuesday", "8:30-10:00", "Room 602");
    allCourses[5][3] = Course("E1L", "Elective 1 Lab", 0, 1, "Dr. Ahmed", "Tuesday", "10:15-11:45", "Room Lab14");
    allCourses[5][4] = Course("E2", "Elective 2", 2, 0, "Dr. Ali", "Wednesday", "8:30-10:00", "Room 603");
    allCourses[5][5] = Course("E2L", "Elective 2 Lab", 0, 1, "Dr. Ali", "Wednesday", "10:15-11:45", "Room Lab15");
    allCourses[5][6] = Course("E3", "Elective 3", 3, 0, "Dr. Khan", "Thursday", "8:30-10:00", "Room 604");
    allCourses[5][7] = Course("SEN 321", "Human Computer Interaction", 2, 0, "Ms. Sara", "Thursday", "10:15-11:45", "Room 605");
    allCourses[5][8] = Course("SEN 320", "HCI Lab", 0, 1, "Ms. Sara", "Friday", "8:30-10:00", "Room Lab16");
    allCourses[5][9] = Course("ISL 112", "Understanding Quran-V", 1, 0, "Mr. Usman", "Friday", "10:15-11:45", "Room 606");

    // sem 7
    courseCountPerSem[6] = 8;
    allCourses[6][0] = Course("FYP 400", "Final Year Project", 3, 0, "Dr. Ahmed", "Monday", "8:30-10:00", "Room 701");
    allCourses[6][1] = Course("CSC 470", "Advanced Databases", 2, 0, "Dr. Ali", "Monday", "10:15-11:45", "Room 702");
    allCourses[6][2] = Course("CSL 470", "Advanced Databases Lab", 0, 1, "Dr. Ali", "Tuesday", "8:30-10:00", "Room Lab17");
    allCourses[6][3] = Course("ESC", "Elective Supporting Course", 3, 0, "Dr. Khan", "Tuesday", "10:15-11:45", "Room 703");
    allCourses[6][4] = Course("E4", "Elective 4", 2, 0, "Dr. Fatima", "Wednesday", "8:30-10:00", "Room 704");
    allCourses[6][5] = Course("E4L", "Elective 4 Lab", 0, 1, "Dr. Fatima", "Wednesday", "10:15-11:45", "Room Lab18");
    allCourses[6][6] = Course("E5", "Elective 5", 2, 0, "Dr. Ahmed", "Thursday", "8:30-10:00", "Room 705");
    allCourses[6][7] = Course("E5L", "Elective 5 Lab", 0, 1, "Dr. Ahmed", "Thursday", "10:15-11:45", "Room Lab19");

    // sem 8
    courseCountPerSem[7] = 8;
    allCourses[7][0] = Course("FYP 400", "Final Year Project", 3, 0, "Dr. Ahmed", "Monday", "8:30-10:00", "Room 801");
    allCourses[7][1] = Course("CSC 407", "Information Security", 3, 0, "Dr. Ali", "Monday", "10:15-11:45", "Room 802");
    allCourses[7][2] = Course("AIC 302", "Parallel & Distributed Computing", 2, 0, "Dr. Khan", "Tuesday", "8:30-10:00", "Room 803");
    allCourses[7][3] = Course("AIL 302", "PDC Lab", 0, 1, "Dr. Khan", "Tuesday", "10:15-11:45", "Room Lab20");
    allCourses[7][4] = Course("E6", "Elective 6", 2, 0, "Dr. Fatima", "Wednesday", "8:30-10:00", "Room 804");
    allCourses[7][5] = Course("E6L", "Elective 6 Lab", 0, 1, "Dr. Fatima", "Wednesday", "10:15-11:45", "Room Lab21");
    allCourses[7][6] = Course("E7", "Elective 7", 3, 0, "Dr. Ahmed", "Thursday", "8:30-10:00", "Room 805");
    allCourses[7][7] = Course("ISL 114", "Seerah-II", 1, 0, "Mr. Usman", "Thursday", "10:15-11:45", "Room 806");
    prereqGraph.addCourse("CSC 113");
    prereqGraph.addCourse("CSC 210");
    prereqGraph.addCourse("CSC 221");
    prereqGraph.addCourse("CSC 320");
    prereqGraph.addCourse("CSC 321");
    prereqGraph.addCourse("CSC 315");
    prereqGraph.addCourse("CSC 323");
    prereqGraph.addCourse("CSC 220");
    prereqGraph.addCourse("CSC 470");
    prereqGraph.addCourse("CEN 122");
    prereqGraph.addCourse("CEN 323");
    prereqGraph.addCourse("CSC 327");
    prereqGraph.addCourse("GSC 110");
    prereqGraph.addCourse("GSC 211");
    prereqGraph.addCourse("AIC 302");
    prereqGraph.addCourse("SEN 220");
    prereqGraph.addCourse("SEN 321");
    prereqGraph.addCourse("ISL 108");
    prereqGraph.addCourse("ISL 109");
    prereqGraph.addCourse("ISL 111");
    prereqGraph.addCourse("ISL 112");
    prereqGraph.addCourse("ISL 114");

    prereqGraph.addPrerequisite("CSC 210", "CSC 113");
    prereqGraph.addPrerequisite("CSC 221", "CSC 113");
    prereqGraph.addPrerequisite("CSC 320", "CSC 221");
    prereqGraph.addPrerequisite("CSC 321", "CSC 221");
    prereqGraph.addPrerequisite("CSC 315", "CSC 221");
    prereqGraph.addPrerequisite("CSC 323", "CSC 315");
    prereqGraph.addPrerequisite("CSC 470", "CSC 220");
    prereqGraph.addPrerequisite("SEN 321", "SEN 220");
    prereqGraph.addPrerequisite("CEN 323", "CEN 122");
    prereqGraph.addPrerequisite("CSC 327", "CEN 323");
    prereqGraph.addPrerequisite("GSC 211", "GSC 110");
    prereqGraph.addPrerequisite("AIC 302", "CSC 320");

    for (int s = 0; s < MAX_SEMESTERS; s++)
    {
        for (int i = 0; i < courseCountPerSem[s]; i++)
        {
            int dayIndex = -1;
            int slotIndex = -1;

            if (allCourses[s][i].day == "Monday")    dayIndex = 0;
            else if (allCourses[s][i].day == "Tuesday")   dayIndex = 1;
            else if (allCourses[s][i].day == "Wednesday") dayIndex = 2;
            else if (allCourses[s][i].day == "Thursday")  dayIndex = 3;
            else if (allCourses[s][i].day == "Friday")    dayIndex = 4;

            if (allCourses[s][i].time == "8:30-10:00")   slotIndex = 0;
            else if (allCourses[s][i].time == "10:15-11:45")  slotIndex = 1;
            else if (allCourses[s][i].time == "12:00-1:30")   slotIndex = 2;
            else if (allCourses[s][i].time == "2:00-3:30")    slotIndex = 3;
            else if (allCourses[s][i].time == "3:45-5:15")    slotIndex = 4;
            else if (allCourses[s][i].time == "5:30-7:00")    slotIndex = 5;

            if (dayIndex != -1 && slotIndex != -1)
                timetable[s].addCourse(dayIndex, slotIndex, allCourses[s][i].code, allCourses[s][i].teacher, allCourses[s][i].room);
        }
    }

    students[0] = Student("02-134261-001", "Alveena Arshad", 1, 3.60); students[0].password = "02-134261-001@alveenaarshad";
    students[1] = Student("02-134261-002", "Muhammad Saad", 1, 2.85); students[1].password = "02-134261-002@muhammadsaad";
    students[2] = Student("02-134261-003", "Hania Amir", 1, 2.95); students[2].password = "02-134261-003@haniaamir";
    students[3] = Student("02-134261-004", "Nazeera Ibrahim", 1, 2.65); students[3].password = "02-134261-004@nazeeraibrahim";
    students[4] = Student("02-134261-005", "Usman Amir", 1, 2.75); students[4].password = "02-134261-005@usmanamir";
    students[30] = Student("02-134261-006", "Ushna Khan", 1, 3.35); students[30].password = "02-134261-006@ushnakhan";

    students[5] = Student("02-134252-001", "Fatima Ansar", 2, 3.75); students[5].password = "02-134252-001@fatimaansar";
    students[6] = Student("02-134252-002", "Adam Khan", 2, 2.55); students[6].password = "02-134252-002@adamkhan";
    students[7] = Student("02-134252-003", "Sana Mir", 2, 2.80); students[7].password = "02-134252-003@sanamir";
    students[8] = Student("02-134252-004", "Rafia Adil", 2, 2.60); students[8].password = "02-134252-004@rafiaadil";

    students[9] = Student("02-134251-001", "Nomana Noor", 3, 3.50); students[9].password = "02-134251-001@nomananoor";
    students[10] = Student("02-134251-002", "Taha Hussain", 3, 2.90); students[10].password = "02-134251-002@tahahussain";
    students[11] = Student("02-134251-003", "Abiha Imran", 3, 3.20); students[11].password = "02-134251-003@abihaimran";

    students[12] = Student("02-134242-001", "Zarnab Khan", 4, 3.90); students[12].password = "02-134242-001@zarnabkhan";
    students[13] = Student("02-134242-002", "Maha Khan", 4, 3.30); students[13].password = "02-134242-002@mahakhan";
    students[14] = Student("02-134242-003", "Rashid Shahzad", 4, 2.70); students[14].password = "02-134242-003@rashidshahzad";
    students[15] = Student("02-134242-004", "Abdullah Imran", 4, 2.50); students[15].password = "02-134242-004@abdullahimran";

    students[16] = Student("02-134233-001", "Maaz Safder", 5, 2.85); students[16].password = "02-134233-001@maazsafder";
    students[17] = Student("02-134233-002", "Ilsa Imran", 5, 3.85); students[17].password = "02-134233-002@ilsaimran";
    students[18] = Student("02-134233-003", "Amna Mujahid", 5, 2.95); students[18].password = "02-134233-003@amnamujahid";

    students[19] = Student("02-134224-001", "Haider Ibrahim", 6, 2.75); students[19].password = "02-134224-001@haideribrahim";
    students[20] = Student("02-134224-002", "Sara Ejaz", 6, 3.55); students[20].password = "02-134224-002@saraejaz";
    students[21] = Student("02-134224-003", "Ayesha Shafique", 6, 3.55); students[21].password = "02-134224-003@ayeshashafique";

    students[22] = Student("02-134215-001", "Zahra Batool", 7, 3.20); students[22].password = "02-134215-001@zahrabatool";
    students[23] = Student("02-134215-002", "Zunaira Nadeem", 7, 2.65); students[23].password = "02-134215-002@zunairanadeem";
    students[24] = Student("02-134215-003", "Zoha Waseem", 7, 2.90); students[24].password = "02-134215-003@zohawaseem";

    students[25] = Student("02-134206-001", "Abdul Hadi", 8, 2.55); students[25].password = "02-134206-001@abdulhadi";
    students[26] = Student("02-134206-002", "Anas Kamran", 8, 2.70); students[26].password = "02-134206-002@anaskamran";
    students[27] = Student("02-134206-003", "Mahnoor Altaf", 8, 2.85); students[27].password = "02-134206-003@mahnooraltaf";
    students[28] = Student("02-134206-004", "Tehreem Ansari", 8, 2.95); students[28].password = "02-134206-004@tehreemansari";
    students[29] = Student("02-134206-005", "Samar Jafri", 8, 2.60); students[29].password = "02-134206-005@samarjafri";

    studentCount = 31;


    string s1comp[] = { "CSC 113", "CSC 114" };
    string s2comp[] = { "CSC 113", "GSC 110", "CSC 114" };
    string s3comp[] = { "CSC 113", "CSC 210", "CEN 122" };
    string s4comp[] = { "CSC 113", "CSC 210", "CSC 221", "CEN 122" };
    string s5comp[] = { "CSC 113", "CSC 210", "CSC 221", "CEN 122", "CEN 323" };
    string s6comp[] = { "CSC 113", "CSC 210", "CSC 221", "CSC 315", "CEN 122", "CEN 323", "SEN 220", "CSC 220" };
    string s7comp[] = { "CSC 113", "CSC 210", "CSC 221", "CSC 315", "CSC 320", "CEN 122", "CEN 323", "SEN 220", "CSC 220" };
    string s8comp[] = { "CSC 113", "CSC 210", "CSC 221", "CSC 315", "CSC 320", "CEN 122", "CEN 323", "SEN 220", "CSC 220" };

    int indices1[] = { 0, 1, 2, 3, 4, 30 };
    int indices2[] = { 5, 6, 7, 8 };
    int indices3[] = { 9, 10, 11 };
    int indices4[] = { 12, 13, 14, 15 };
    int indices5[] = { 16, 17, 18 };
    int indices6[] = { 19, 20, 21 };
    int indices7[] = { 22, 23, 24 };
    int indices8[] = { 25, 26, 27, 28, 29 };

    // Sem 1 students
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 2; j++)
            students[indices1[i]].addCompletedCourse(s1comp[j]);

    // Sem 2 students
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 3; j++)
            students[indices2[i]].addCompletedCourse(s2comp[j]);

    // Sem 3 students
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            students[indices3[i]].addCompletedCourse(s3comp[j]);

    // Sem 4 students
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            students[indices4[i]].addCompletedCourse(s4comp[j]);

    // Sem 5 students
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 5; j++)
            students[indices5[i]].addCompletedCourse(s5comp[j]);

    // Sem 6 students
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 8; j++)
            students[indices6[i]].addCompletedCourse(s6comp[j]);

    // Sem 7 students
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 9; j++)
            students[indices7[i]].addCompletedCourse(s7comp[j]);

    // Sem 8 students
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 9; j++)
            students[indices8[i]].addCompletedCourse(s8comp[j]);

    // Enroll all students in their semester courses
    for (int i = 0; i < studentCount; i++)
        enrollStudentInSemesterCourses(students[i], allCourses, courseCountPerSem);
}

void Admin::viewCourseEnrollmentDetails(Course courses[][MAX_COURSES_PER_SEM], int semesterCourseCount[],
    Student students[], int studentCount)
{
    cout << BLUE << "\n   COURSE ENROLLMENT DETAILS:\n" << RESET;
    cout << "   Select semester (1-8): ";
    int sem = inputInt("");
    if (sem < 1 || sem > MAX_SEMESTERS) { cout << RED << "   [ERROR] Invalid semester! Please enter a value between 1 and 8.\n" << RESET; return; }

    int semIndex = sem - 1;
    cout << CYAN << "\n   Semester " << sem << " courses:\n" << RESET;
    for (int i = 0; i < semesterCourseCount[semIndex]; i++)
        cout << "     " << (i + 1) << ". " << courses[semIndex][i].code << " - " << courses[semIndex][i].name << "\n";

    cout << "   Enter course number (0 to cancel): ";
    int courseNum = inputInt("");
    if (courseNum == 0) { cout << YELLOW << "   [INFO] Cancelled.\n" << RESET; return; }
    if (courseNum < 1 || courseNum > semesterCourseCount[semIndex])
    {
        cout << RED << "   [ERROR] Invalid course number!\n" << RESET; return;
    }
    cout << CYAN << "\n   ENROLLED STUDENTS in " << courses[semIndex][courseNum - 1].code
        << " - " << courses[semIndex][courseNum - 1].name << ":\n" << RESET;
    courses[semIndex][courseNum - 1].enrolledStudents.displayStudents();
}

void Admin::checkPrerequisiteAlert(Student& student, string courseCode, PrerequisiteGraph& prereqGraph)
{
    if (courseCode.empty())
    {
        cout << RED << "   [ERROR] Course code cannot be empty!\n" << RESET;
        return;
    }
    if (!prereqGraph.courseExists(courseCode))
    {
        cout << RED << "   [ERROR] Course '" << courseCode << "' does not exist!\n" << RESET;
        return;
    }
    vector<string> completed = student.getCompletedCourses();
    if (prereqGraph.checkPrerequisites(courseCode, completed))
        cout << GREEN << "   [SUCCESS] " << student.name << " meets all prerequisites for " << courseCode << "!\n" << RESET;
    else
        cout << RED << "   [ERROR] " << student.name << " has missing prerequisites!\n" << RESET;
}

void Student::showMenu(Course allCourses[][MAX_COURSES_PER_SEM], int semesterCourseCount[],
    PrerequisiteGraph& prereqGraph, Timetable timetable[],
    int studentIndex, Student students[], int studentCount)
{
    int choice;
    do
    {
        cout << CYAN;
        cout << "\n   +--------------------------------------------------+\n";
        cout << "   |               STUDENT PORTAL                     |\n";
        cout << "   +--------------------------------------------------+\n";
        cout << "   |  1.  View All Courses                            |\n";
        cout << "   |  2.  Register Course                             |\n";
        cout << "   |  3.  Drop Course                                 |\n";
        cout << "   |  4.  My Enrolled Courses                         |\n";
        cout << "   |  5.  View Timetable                              |\n";
        cout << "   |  6.  Check Attendance                            |\n";
        cout << "   |  7.  Assignment Reminders                        |\n";
        cout << "   |  8.  Submit Assignment                           |\n";
        cout << "   |  9.  Submission History                          |\n";
        cout << "   |  10. Undo Last Submission                        |\n";
        cout << "   |  11. View Notifications                          |\n";
        cout << "   |  12. My GPA and Ranking                          |\n";
        cout << "   |  0.  Logout                                      |\n";
        cout << "   +--------------------------------------------------+\n";
        cout << RESET;
        cout << "   Enter choice: ";
        choice = inputInt("");

        switch (choice)
        {
        case 1:
        {
            cout << BLUE << "\n   ALL COURSES (Semester " << semester << "):\n" << RESET;
            int semIndex = semester - 1;
            for (int i = 0; i < courseCountPerSem[semIndex]; i++)
            {
                allCourses[semIndex][i].displayInfo();
                cout << "\n";
            }
            break;
        }
        case 2:
        {
            int semIndex = semester - 1;
            if (semIndex < 0 || semIndex >= MAX_SEMESTERS)
            {
                cout << RED << "   [ERROR] Invalid semester!\n" << RESET; break;
            }
            cout << CYAN << "\n   Available Courses:\n" << RESET;
            for (int i = 0; i < courseCountPerSem[semIndex]; i++)
                cout << "     " << (i + 1) << ". " << allCourses[semIndex][i].code << " - " << allCourses[semIndex][i].name << "\n";

            cout << "   Enter course number to register (0 to cancel): ";
            int courseNum = inputInt("");
            if (courseNum == 0) { cout << YELLOW << "   [INFO] Registration cancelled.\n" << RESET; break; }
            if (courseNum < 1 || courseNum > courseCountPerSem[semIndex])
            {
                cout << RED << "   [ERROR] Invalid course number!\n" << RESET; break;
            }
            string courseCode = allCourses[semIndex][courseNum - 1].code;
            if (enrolledCourses.hasCourse(courseCode))
            {
                cout << RED << "   [ERROR] Already enrolled in this course!\n" << RESET; break;
            }
            vector<string> completed = getCompletedCourses();
            if (prereqGraph.checkPrerequisites(courseCode, completed))
            {
                enrolledCourses.addCourse(courseCode, allCourses[semIndex][courseNum - 1].name);
                allCourses[semIndex][courseNum - 1].enrolledStudents.addStudent(id, name);
                cout << GREEN << "   [SUCCESS] Registered for " << courseCode << "!\n" << RESET;
                notificationQueue.enqueue("Registered for " + courseCode, "Today");
            }
            else
            {
                cout << RED << "   [ERROR] Cannot register! Missing prerequisites.\n" << RESET;
                prereqGraph.displayPrerequisites(courseCode);
            }
            break;
        }
        case 3:
        {
            cout << YELLOW << "\n   Your Enrolled Courses:\n" << RESET;
            enrolledCourses.displayCourses();
            cout << "   Enter course code to drop (e.g., CSC 221): ";
            string dropCode = inputLine("");
            if (dropCode.empty())
            {
                cout << RED << "   [ERROR] Course code cannot be empty!\n" << RESET; break;
            }
            if (enrolledCourses.hasCourse(dropCode))
            {
                enrolledCourses.removeCourse(dropCode);
                for (int s = 0; s < MAX_SEMESTERS; s++)
                    for (int c = 0; c < courseCountPerSem[s]; c++)
                        if (allCourses[s][c].code == dropCode)
                        {
                            allCourses[s][c].enrolledStudents.removeStudent(id);
                            break;
                        }
                cout << GREEN << "   [SUCCESS] Dropped course " << dropCode << "!\n" << RESET;
                notificationQueue.enqueue("Dropped " + dropCode, "Today");
            }
            else
            {
                cout << RED << "   [ERROR] You are not enrolled in " << dropCode << "!\n" << RESET;
            }
            break;
        }
        case 4:
        {
            cout << CYAN << "\n   MY ENROLLED COURSES:\n" << RESET;
            enrolledCourses.displayCourses();
            break;
        }
        case 5:
        {
            int semIndex = semester - 1;
            if (semIndex >= 0 && semIndex < MAX_SEMESTERS)
            {
                cout << BLUE << "\n   TIMETABLE FOR SEMESTER " << semester << ":\n" << RESET;
                timetable[semIndex].display();
            }
            break;
        }
        case 6:
        {
            cout << YELLOW << "\n   ATTENDANCE REPORT:\n" << RESET;
            cout << "     +------------+------------+--------+\n";
            cout << "     | Course     | Attendance | Status |\n";
            cout << "     +------------+------------+--------+\n";
            CourseNode* current = enrolledCourses.getHead();
            bool hasData = false;
            while (current)
            {
                for (int s = 0; s < MAX_SEMESTERS; s++)
                    for (int c = 0; c < courseCountPerSem[s]; c++)
                        if (allCourses[s][c].code == current->courseCode)
                        {
                            double att = allCourses[s][c].attendancePercentage;
                            string status = (att < 75) ? "LOW" : "OK";
                            cout << "     | " << left << setw(10) << current->courseCode
                                << " | " << setw(9) << fixed << setprecision(1) << att << "%"
                                << " | " << setw(6) << status << " |\n";
                            hasData = true;
                            break;
                        }
                current = current->next;
            }
            if (!hasData) cout << "     | No enrolled courses.                        |\n";
            cout << "     +------------+------------+--------+\n";
            cout << YELLOW << "\n   ATTENDANCE ALERTS:\n" << RESET;
            checkAttendanceAlert(allCourses[semester - 1], courseCountPerSem[semester - 1]);
            break;
        }
        case 7:
        {
            cout << MAGENTA << "\n   ASSIGNMENT DEADLINE REMINDERS:\n" << RESET;
            CourseNode* current = enrolledCourses.getHead();
            if (!current) { cout << "     No upcoming deadlines.\n"; break; }
            cout << "     +------------+------------------------------------+\n";
            cout << "     | Course     | Deadline                           |\n";
            cout << "     +------------+------------------------------------+\n";
            while (current)
            {
                cout << "     | " << left << setw(10) << current->courseCode
                    << " | Assignment due tomorrow (11:59 PM) |\n";
                current = current->next;
            }
            cout << "     +------------+------------------------------------+\n";
            break;
        }
        case 8:
        {
            cout << "   Enter course code (e.g., CSC 221): ";
            string subCode = inputLine("");
            if (subCode.empty())
            {
                cout << RED << "   [ERROR] Course code cannot be empty!\n" << RESET; break;
            }
            if (enrolledCourses.hasCourse(subCode))
            {
                cout << "   Enter assignment name: ";
                string assignName = inputLine("");
                if (assignName.empty())
                {
                    cout << RED << "   [ERROR] Assignment name cannot be empty!\n" << RESET; break;
                }
                submissionStack.push(subCode, assignName, "Today");
            }
            else
            {
                cout << RED << "   [ERROR] You are not enrolled in " << subCode << "!\n" << RESET;
            }
            break;
        }
        case 9:
        {
            cout << CYAN << "\n   SUBMISSION HISTORY:\n" << RESET;
            submissionStack.display();
            break;
        }
        case 10:
        {
            submissionStack.pop();
            break;
        }
        case 11:
        {
            notificationQueue.displayAll();
            while (!notificationQueue.isEmpty()) notificationQueue.dequeue();
            break;
        }
        case 12:
        {
            cout << MAGENTA << "\n   MY ACADEMIC INFO:\n" << RESET;
            cout << "     +--------------------------------+\n";
            cout << "     | Name     : " << left << setw(19) << name << " |\n";
            cout << "     | ID       : " << left << setw(19) << id << " |\n";
            cout << "     | Semester : " << left << setw(19) << semester << " |\n";
            cout << "     | CGPA     : " << left << setw(19) << fixed << setprecision(2) << gpa << " |\n";

       
            QuickSort::StudentScore* scores = new QuickSort::StudentScore[studentCount];
            for (int i = 0; i < studentCount; i++)
            {
                scores[i].name = students[i].name;
                scores[i].id = students[i].id;
                scores[i].gpa = students[i].gpa;
            }

            QuickSort qs;
            qs.sort(scores, 0, studentCount - 1);

            int rank = 1;
            for (int i = 0; i < studentCount; i++)
            {
                if (scores[i].id == id)
                {
                    string rankStr = to_string(rank) + " / " + to_string(studentCount);
                    cout << "     | Rank     : " << left << setw(19) << rankStr << " |\n";
                    break;
                }
                rank++;
            }
            cout << "     +--------------------------------+\n";
            delete[] scores;
            break;
        }
        case 0:
            cout << GREEN << "\n   Logging out...\n" << RESET;
            break;
        default:
            cout << RED << "   [ERROR] Invalid choice! Please enter a number between 0 and 12.\n" << RESET;
        }
    } while (choice != 0);
}

void Admin::manageStudentCourses(Student students[], int studentCount,
    Course courses[][MAX_COURSES_PER_SEM], int semesterCourseCount[])
{
    cout << BLUE << "\n   STUDENT COURSE MANAGEMENT:\n" << RESET;

    int displayCounter = 1;
    int studentIndices[100];
    int idxCount = 0;

    cout << "     +----+----------------------+--------------------+-----+------+\n";
    cout << "     | #  | Name                 | ID                 | Sem | GPA  |\n";
    cout << "     +----+----------------------+--------------------+-----+------+\n";

    for (int sem = 1; sem <= MAX_SEMESTERS; sem++)
    {
        bool hasStudents = false;
        for (int i = 0; i < studentCount; i++)
        {
            if (students[i].semester == sem)
            {
                if (!hasStudents)
                {
                    cout << "     |--- SEMESTER " << sem << " " << string(45, '-') << "|\n";
                    hasStudents = true;
                }
                cout << "     | " << left << setw(2) << displayCounter++
                    << " | " << setw(20) << students[i].name
                    << " | " << setw(18) << students[i].id
                    << " | " << setw(3) << students[i].semester
                    << " | " << fixed << setprecision(2) << setw(4) << students[i].gpa << " |\n";
                studentIndices[idxCount] = i;
                idxCount++;
            }
        }
    }
    cout << "     +----+----------------------+--------------------+-----+------+\n";

    cout << "   Enter student number (0 to cancel): ";
    int sel = inputInt("");
    if (sel == 0) { cout << YELLOW << "   [INFO] Cancelled.\n" << RESET; return; }
    if (sel < 1 || sel > idxCount)
    {
        cout << RED << "   [ERROR] Invalid student number! Please enter a number between 1 and " << idxCount << ".\n" << RESET;
        return;
    }

    int idx = studentIndices[sel - 1];
    cout << CYAN << "\n   " << students[idx].name << "'s Enrolled Courses:\n" << RESET;
    students[idx].enrolledCourses.displayCourses();

    cout << "\n   [A] Add course   [R] Remove course   [B] Back: ";
    string actionStr = inputLine("");
    char action = actionStr.empty() ? 'B' : toupper(actionStr[0]);

    if (action == 'A')
    {
        int semIndex = students[idx].semester - 1;
        cout << "\n   Available courses for Semester " << students[idx].semester << ":\n";
        for (int i = 0; i < semesterCourseCount[semIndex]; i++)
            cout << "     " << (i + 1) << ". " << courses[semIndex][i].code << " - " << courses[semIndex][i].name << "\n";

        cout << "   Enter course number: ";
        int courseNum = inputInt("");
        if (courseNum < 1 || courseNum > semesterCourseCount[semIndex])
        {
            cout << RED << "   [ERROR] Invalid course number!\n" << RESET;
            return;
        }
        string code = courses[semIndex][courseNum - 1].code;
        string cname = courses[semIndex][courseNum - 1].name;
        if (!students[idx].enrolledCourses.hasCourse(code))
        {
            students[idx].enrolledCourses.addCourse(code, cname);
            courses[semIndex][courseNum - 1].enrolledStudents.addStudent(students[idx].id, students[idx].name);
            cout << GREEN << "   [SUCCESS] Course added!\n" << RESET;
        }
        else
        {
            cout << RED << "   [ERROR] Student already enrolled!\n" << RESET;
        }
    }
    else if (action == 'R')
    {
        cout << "   Enter course code to remove (e.g., CSC 221): ";
        string remCode = inputLine("");
        if (remCode.empty())
        {
            cout << RED << "   [ERROR] Course code cannot be empty!\n" << RESET; return;
        }
        if (students[idx].enrolledCourses.hasCourse(remCode))
        {
            students[idx].enrolledCourses.removeCourse(remCode);
            for (int s = 0; s < MAX_SEMESTERS; s++)
                for (int c = 0; c < semesterCourseCount[s]; c++)
                    if (courses[s][c].code == remCode)
                    {
                        courses[s][c].enrolledStudents.removeStudent(students[idx].id);
                        break;
                    }
            cout << GREEN << "   [SUCCESS] Course removed!\n" << RESET;
        }
        else
        {
            cout << RED << "   [ERROR] Student not enrolled in this course!\n" << RESET;
        }
    }
    else if (action != 'B')
    {
        cout << RED << "   [ERROR] Invalid option! Please enter A, R, or B.\n" << RESET;
    }
}
void Admin::manageTimetable(Timetable timetable[], Course courses[][MAX_COURSES_PER_SEM], int semesterCourseCount[])
{
    cout << BLUE << "\n   TIMETABLE MANAGEMENT:\n" << RESET;
    cout << "   Select semester (1-8): ";
    int sem = inputInt("");
    if (sem < 1 || sem > MAX_SEMESTERS) { cout << RED << "   [ERROR] Invalid semester! Please enter a value between 1 and 8.\n" << RESET; return; }

    int semIndex = sem - 1;
    timetable[semIndex].display();

    cout << "\n   [E] Edit Slot   [V] View Courses   [B] Back: ";
    string actionStr = inputLine("");
    char action = actionStr.empty() ? 'B' : toupper(actionStr[0]);

    if (action == 'E')
    {
        cout << "   Select day (1=Mon,2=Tue,3=Wed,4=Thu,5=Fri): ";
        int day = inputInt("");
        if (day < 1 || day > 5) { cout << RED << "   [ERROR] Invalid day!\n" << RESET; return; }

        cout << "   Select slot (1=8:30,2=10:15,3=12:00,4=2:00,5=3:45,6=5:30): ";
        int slot = inputInt("");
        if (slot < 1 || slot > 6) { cout << RED << "   [ERROR] Invalid slot!\n" << RESET; return; }

        cout << "   Enter course code: ";
        string code = inputLine("");
        if (code.empty()) { cout << RED << "   [ERROR] Course code cannot be empty!\n" << RESET; return; }

        cout << "   Enter teacher name: ";
        string teacher = inputLine("");
        if (teacher.empty()) { cout << RED << "   [ERROR] Teacher name cannot be empty!\n" << RESET; return; }

        cout << "   Enter room number: ";
        string room = inputLine("");
        if (room.empty()) { cout << RED << "   [ERROR] Room cannot be empty!\n" << RESET; return; }

        timetable[semIndex].addCourse(day - 1, slot - 1, code, teacher, room);
        cout << GREEN << "   [SUCCESS] Timetable updated!\n" << RESET;
    }
    else if (action == 'V')
    {
        cout << "\n   Courses for Semester " << sem << ":\n";
        for (int i = 0; i < semesterCourseCount[semIndex]; i++)
        {
            courses[semIndex][i].displayInfo();
            cout << "\n";
        }
    }
    else if (action != 'B')
    {
        cout << RED << "   [ERROR] Invalid option! Please enter E, V, or B.\n" << RESET;
    }
}
void Admin::showMenu(Student students[], int& studentCount, Course allCourses[][MAX_COURSES_PER_SEM],
    int semesterCourseCount[], PrerequisiteGraph& prereqGraph,
    Timetable timetable[], HashTable& loginSystem)
{
    int choice;
    do
    {
        cout << MAGENTA;
        cout << "\n   +--------------------------------------------------+\n";
        cout << "   |                 ADMIN PORTAL                     |\n";
        cout << "   +--------------------------------------------------+\n";
        cout << "   |  1.  View All Students                           |\n";
        cout << "   |  2.  Manage Student Courses                      |\n";
        cout << "   |  3.  View / Edit Timetable                       |\n";
        cout << "   |  4.  Check Prerequisite Alert for Student        |\n";
        cout << "   |  5.  Top Performing Students                     |\n";
        cout << "   |  6.  Sort Courses Alphabetically                 |\n";
        cout << "   |  7.  Search Course (BST)                         |\n";
        cout << "   |  8.  View Course Enrollment Details              |\n";
        cout << "   |  9.  Add New Student                             |\n";
        cout << "   |  0.  Logout                                      |\n";
        cout << "   +--------------------------------------------------+\n";
        cout << RESET;
        cout << "   Enter choice: ";
        choice = inputInt("");

        switch (choice)
        {
        case 1:
        {
            cout << CYAN << "\n   ALL STUDENTS (Sorted by Semester):\n" << RESET;
            cout << "     +----------------------+--------------------+-----+------+\n";
            cout << "     | Name                 | ID                 | Sem | GPA  |\n";
            cout << "     +----------------------+--------------------+-----+------+\n";
            for (int sem = 1; sem <= MAX_SEMESTERS; sem++)
            {
                bool hasStudents = false;
                for (int i = 0; i < studentCount; i++)
                {
                    if (students[i].semester == sem)
                    {
                        if (!hasStudents)
                        {
                            cout << "     |--- SEMESTER " << sem << " " << string(45, '-') << "|\n";
                            hasStudents = true;
                        }
                        cout << "     | " << left << setw(20) << students[i].name
                            << " | " << setw(18) << students[i].id
                            << " | " << setw(3) << students[i].semester
                            << " | " << fixed << setprecision(2) << setw(4) << students[i].gpa << " |\n";
                    }
                }
            }
            cout << "     +----------------------+--------------------+-----+------+\n";
            break;
        }
        case 2: manageStudentCourses(students, studentCount, allCourses, semesterCourseCount); break;
        case 3: manageTimetable(timetable, allCourses, semesterCourseCount); break;
        case 4:
        {
            cout << "\n   Select student:\n";
            cout << "     +----+----------------------+-----+\n";
            cout << "     | #  | Name                 | Sem |\n";
            cout << "     +----+----------------------+-----+\n";
            for (int i = 0; i < studentCount; i++)
                cout << "     | " << left << setw(2) << (i + 1)
                << " | " << setw(20) << students[i].name
                << " | " << setw(3) << students[i].semester << " |\n";
            cout << "     +----+----------------------+-----+\n";

            cout << "   Enter choice: ";
            int stuChoice = inputInt("");
            if (stuChoice < 1 || stuChoice > studentCount)
            {
                cout << RED << "   [ERROR] Invalid choice! Please enter a number between 1 and " << studentCount << ".\n" << RESET;
                break;
            }
            cout << "   Enter course code to check (e.g., CSC 221): ";
            string courseCode = inputLine("");
            if (courseCode.empty())
            {
                cout << RED << "   [ERROR] Course code cannot be empty!\n" << RESET; break;
            }
            checkPrerequisiteAlert(students[stuChoice - 1], courseCode, prereqGraph);
            break;
        }
        case 5:
        {
           
            if (studentCount == 0) { cout << RED << "   No students found!\n" << RESET; break; }

            string names[100];
            string ids[100];
            double gpas[100];
            for (int i = 0; i < studentCount; i++)
            {
                names[i] = students[i].name;
                ids[i] = students[i].id;
                gpas[i] = students[i].gpa;
            }

            MaxHeap heap(studentCount);
            heap.loadStudents(names, ids, gpas, studentCount);
            heap.displayTop(5);
            break;
        }
        case 6:
        {
           
            cout << "   Select semester (1-8): ";
            int sem = inputInt("");
            if (sem < 1 || sem > MAX_SEMESTERS)
            {
                cout << RED << "   [ERROR] Invalid semester! Please enter a value between 1 and 8.\n" << RESET; break;
            }
            int semIndex = sem - 1;
            string* courseNames = new string[semesterCourseCount[semIndex]];
            for (int i = 0; i < semesterCourseCount[semIndex]; i++)
                courseNames[i] = allCourses[semIndex][i].name;

            MergeSort ms;
            ms.sort(courseNames, 0, semesterCourseCount[semIndex] - 1);

            cout << CYAN << "\n   COURSES (Alphabetical Order):\n" << RESET;
            for (int i = 0; i < semesterCourseCount[semIndex]; i++)
                cout << "     " << (i + 1) << ". " << courseNames[i] << "\n";
            delete[] courseNames;
            break;
        }
        case 7:
        {
            BinarySearchTree bst;
            for (int s = 0; s < MAX_SEMESTERS; s++)
                for (int c = 0; c < semesterCourseCount[s]; c++)
                    bst.insert(allCourses[s][c].code, allCourses[s][c].name);

            cout << "   Enter course code to search (e.g., CSC 221): ";
            string searchCode = inputLine("");
            if (searchCode.empty())
            {
                cout << RED << "   [ERROR] Course code cannot be empty!\n" << RESET; break;
            }
            string result = bst.search(searchCode);
            if (!result.empty())
                cout << GREEN << "   [FOUND] " << searchCode << " - " << result << "\n" << RESET;
            else
                cout << RED << "   [NOT FOUND] Course not found!\n" << RESET;
            break;
        }
        case 8: viewCourseEnrollmentDetails(allCourses, semesterCourseCount, students, studentCount); break;
        case 9:
        {
            cout << CYAN << "\n   ADD NEW STUDENT:\n" << RESET;

            cout << "   Enter Student ID (e.g., 02-134261-007): ";
            string newId = inputLine("");
            if (newId.empty())
            {
                cout << RED << "   [ERROR] Student ID cannot be empty!\n" << RESET; break;
            }

            bool alreadyExists = false;
            for (int i = 0; i < studentCount; i++)
            {
                if (students[i].id == newId) { alreadyExists = true; break; }
            }
            if (alreadyExists)
            {
                cout << RED << "   [ERROR] Student with ID " << newId << " already exists!\n" << RESET;
                break;
            }

            if (studentCount >= 100)
            {
                cout << RED << "   [ERROR] Maximum student capacity (100) reached!\n" << RESET; break;
            }

            cout << "   Enter Student Name: ";
            string newName = inputLine("");
            if (newName.empty())
            {
                cout << RED << "   [ERROR] Student name cannot be empty!\n" << RESET; break;
            }

            cout << "   Enter Semester (1-8): ";
            int newSem = inputInt("");
            if (newSem < 1 || newSem > MAX_SEMESTERS)
            {
                cout << RED << "   [ERROR] Invalid semester! Please enter a value between 1 and 8.\n" << RESET; break;
            }

            cout << "   Enter CGPA (0.00 - 4.00): ";
            double newGpa = inputDouble("");
            if (newGpa < 0.0 || newGpa > 4.0)
            {
                cout << RED << "   [ERROR] Invalid CGPA! Please enter a value between 0.00 and 4.00.\n" << RESET; break;
            }

            string rawPassword = newId + "@";
            for (int i = 0; i < (int)newName.size(); i++)
                if (newName[i] != ' ') rawPassword += tolower(newName[i]);

            students[studentCount] = Student(newId, newName, newSem, newGpa);
            students[studentCount].password = rawPassword;
            enrollStudentInSemesterCourses(students[studentCount], allCourses, semesterCourseCount);
            loginSystem.insert(newId, rawPassword, "student");

            cout << GREEN << "\n   [SUCCESS] Student added successfully!\n" << RESET;
            cout << YELLOW << "   [INFO] Student enrolled in Semester " << newSem << " courses.\n" << RESET;
            cout << YELLOW << "   [INFO] Password: " << rawPassword << "\n" << RESET;

            studentCount++;
            break;
        }
        case 0:
            cout << GREEN << "\n   Logging out...\n" << RESET;
            break;
        default:
            cout << RED << "   [ERROR] Invalid choice! Please enter a number between 0 and 9.\n" << RESET;
        }
    } while (choice != 0);
}

int main()
{
    cout << BOLD << CYAN;
    cout << "\n   +====================================================+\n";
    cout << "   |    BAHRIA UNIVERSITY - COURSE MANAGEMENT SYSTEM    |\n";
    cout << "   +====================================================+\n";
    cout << RESET;

    initializeData();

    HashTable loginSystem;
    loginSystem.insert("bu_admin", "BU@CMS2026", "admin");
    for (int i = 0; i < studentCount; i++)
        loginSystem.insert(students[i].id, students[i].password, "student");

    Admin admin;
    int mainChoice;

    do
    {
        cout << YELLOW;
        cout << "\n   +--------------------------------------------------+\n";
        cout << "   |                   MAIN MENU                      |\n";
        cout << "   +--------------------------------------------------+\n";
        cout << "   |  1.  Admin Login                                 |\n";
        cout << "   |  2.  Student Login                               |\n";
        cout << "   |  0.  Exit                                        |\n";
        cout << "   +--------------------------------------------------+\n";
        cout << RESET;
        cout << "   Enter choice: ";
        mainChoice = inputInt("");

        if (mainChoice == 1)
        {
            cout << "   Username: ";
            string user = inputLine("");
            cout << "   Password: ";
            string pass = inputLine("");
            string role;
            if (loginSystem.authenticate(user, pass, role) && role == "admin")
            {
                cout << GREEN << "\n   [SUCCESS] Welcome Admin!\n" << RESET;
                admin.showMenu(students, studentCount, allCourses, courseCountPerSem, prereqGraph, timetable, loginSystem);
            }
            else
            {
                cout << RED << "\n   [ERROR] Invalid admin credentials!\n" << RESET;
            }
        }
        else if (mainChoice == 2)
        {
            cout << "   Student ID: ";
            string user = inputLine("");
            cout << "   Password: ";
            string pass = inputLine("");
            string role;
            if (loginSystem.authenticate(user, pass, role) && role == "student")
            {
                int studentIndex = -1;
                for (int i = 0; i < studentCount; i++)
                    if (students[i].id == user) { studentIndex = i; break; }
                if (studentIndex != -1)
                {
                    cout << GREEN << "\n   [SUCCESS] Welcome " << students[studentIndex].name << "!\n" << RESET;
                    students[studentIndex].showMenu(allCourses, courseCountPerSem, prereqGraph,
                        timetable, studentIndex, students, studentCount);
                }
                else
                {
                    cout << RED << "   [ERROR] Student record not found!\n" << RESET;
                }
            }
            else
            {
                cout << RED << "\n   [ERROR] Invalid student credentials!\n" << RESET;
            }
        }
        else if (mainChoice != 0)
        {
            cout << RED << "   [ERROR] Invalid choice! Please enter 0, 1, or 2.\n" << RESET;
        }
    } while (mainChoice != 0);

    cout << GREEN << "\n   Thank you for using Bahria University CMS. Goodbye!\n\n" << RESET;
    return 0;
}